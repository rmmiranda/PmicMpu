// EXPORTED FUNCTIONS
#include <map>
_STD_BEGIN

template<class _Kty, class _Ty, class _Pr, class _Alloc>
	template<class _Iter>
	map<_Kty, _Ty, _Pr, _Alloc>::map(_Iter _First, _Iter _Last)
	: _Mybase(key_compare(), allocator_type())
	{	// construct map from [_First, _Last), defaults
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Ty, class _Pr, class _Alloc>
	template<class _Iter>
	map<_Kty, _Ty, _Pr, _Alloc>::map(_Iter _First, _Iter _Last,
		const key_compare& _Pred)
	: _Mybase(_Pred, allocator_type())
	{	// construct map from [_First, _Last), comparator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Ty, class _Pr, class _Alloc>
	template<class _Iter>
	map<_Kty, _Ty, _Pr, _Alloc>::map(_Iter _First, _Iter _Last,
		const key_compare& _Pred, const allocator_type& _Al)
	: _Mybase(_Pred, _Al)
	{	// construct map from [_First, _Last), comparator, and allocator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Ty, class _Pr, class _Alloc>
	template<class _Iter>
	multimap<_Kty, _Ty, _Pr, _Alloc>::multimap(_Iter _First, _Iter _Last)
	: _Mybase(key_compare(), allocator_type())
	{	// construct map from [_First, _Last), defaults
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		insert(*_First);
	}

template<class _Kty, class _Ty, class _Pr, class _Alloc>
	template<class _Iter>
	multimap<_Kty, _Ty, _Pr, _Alloc>::multimap(_Iter _First, _Iter _Last,
		const key_compare& _Pred)
	: _Mybase(_Pred, allocator_type())
	{	// construct map from [_First, _Last), comparator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		insert(*_First);
	}

template<class _Kty, class _Ty, class _Pr, class _Alloc>
	template<class _Iter>
	multimap<_Kty, _Ty, _Pr, _Alloc>::multimap(_Iter _First, _Iter _Last,
		const key_compare& _Pred, const allocator_type& _Al)
	: _Mybase(_Pred, _Al)
	{	// construct map from [_First, _Last), comparator, and allocator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		insert(*_First);
	}

template<class _Kty, class _Ty, class _Pr, class _Alloc>
	template<class _Iter>
	void multimap<_Kty, _Ty, _Pr, _Alloc>::insert(_Iter _First, _Iter _Last)
	{	// insert [_First, _Last), arbitrary iterators

 #if _HAS_ITERATOR_DEBUGGING
	_DEBUG_RANGE(_First, _Last);
	if (_Debug_get_cont(_First) == this)
		_DEBUG_ERROR("multimap insertion overlaps range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	for (; _First != _Last; ++_First)
		insert(*_First);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */

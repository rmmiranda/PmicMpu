// EXPORTED FUNCTIONS
#include <ostream>
_STD_BEGIN

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(_Bool _Val)
	{	// insert a boolean
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(short _Val)
	{	// insert a short
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());
		ios_base::fmtflags _Bfl =
			ios_base::flags() & ios_base::basefield;
		long _Tmp = (_Bfl == ios_base::oct
			|| _Bfl == ios_base::hex)
			? (long)(unsigned short)_Val : (long)_Val;

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Tmp).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(unsigned short _Val)
	{	// insert an unsigned short
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), (unsigned long)_Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(int _Val)
	{	// insert an int
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());
		ios_base::fmtflags _Bfl =
			ios_base::flags() & ios_base::basefield;
		long _Tmp = (_Bfl == ios_base::oct
			|| _Bfl == ios_base::hex)
			? (long)(unsigned int)_Val : (long)_Val;

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Tmp).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(unsigned int _Val)
	{	// insert an unsigned int
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), (unsigned long)_Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(long _Val)
	{	// insert a long
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(unsigned long _Val)
	{	// insert an unsigned long
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(_LONGLONG _Val)
	{	// insert a long long
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(_ULONGLONG _Val)
	{	// insert an unsigned long long
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(float _Val)
	{	// insert a float
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), (double)_Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(double _Val)
	{	// insert a double
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(long double _Val)
	{	// insert a long double
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(const void *_Val)
	{	// insert a void pointer
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to insert
		const _Nput& _Nput_fac = use_facet< _Nput >(ios_base::getloc());

		_TRY_IO_BEGIN
		if (_Nput_fac.put(_Iter(_Myios::rdbuf()), *this,
			_Myios::fill(), _Val).failed())
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::operator<<(_Mysb *_Strbuf)
	{	// insert until end-of-file from a stream buffer
	ios_base::iostate _State = ios_base::goodbit;
	bool _Copied = false;
	const sentry _Ok(*this);

	if (_Ok && _Strbuf != 0)
		for (int_type _Meta = _Traits::eof(); ; _Copied = true)
			{	// extract another character from stream buffer
			_TRY_BEGIN
			_Meta = _Traits::eq_int_type(_Traits::eof(), _Meta)
				? _Strbuf->sgetc() : _Strbuf->snextc();
			_CATCH_ALL
				_Myios::setstate(ios_base::failbit);
				_RERAISE;
			_CATCH_END

			if (_Traits::eq_int_type(_Traits::eof(), _Meta))
				break;	// end of file, quit

			_TRY_IO_BEGIN
				if (_Traits::eq_int_type(_Traits::eof(),
					_Myios::rdbuf()->sputc(
						_Traits::to_char_type(_Meta))))
					{	// insertion failed, quit
					_State |= ios_base::badbit;
					break;
					}
			_CATCH_IO_END
			}

	ios_base::width(0);
	_Myios::setstate(_Strbuf == 0 ? ios_base::badbit
		: !_Copied ? _State | ios_base::failbit : _State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::put(_Elem _Ch)
	{	// insert a character
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (!_Ok)
		_State |= ios_base::badbit;
	else
		{	// state okay, insert character
		_TRY_IO_BEGIN
		if (_Traits::eq_int_type(_Traits::eof(),
			_Myios::rdbuf()->sputc(_Ch)))
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_ostream<_Elem, _Traits>& basic_ostream<_Elem, _Traits>::write(const _Elem *_Str,
	streamsize _Count)
	{	// insert _Count characters from array _Str
	_DEBUG_POINTER(_Str);
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (!_Ok)
		_State |= ios_base::badbit;
	else
		{	// state okay, insert characters
		_TRY_IO_BEGIN
		if (_Myios::rdbuf()->sputn(_Str, _Count) != _Count)
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem,
	class _Traits>
	basic_ostream<_Elem, _Traits>& operator<<(
		basic_ostream<_Elem, _Traits>& _Ostr, const char *_Val)
	{	// insert NTBS
	ios_base::iostate _State = ios_base::goodbit;
	streamsize _Count = (streamsize)_CSTD strlen(_Val);	// may overflow
	streamsize _Pad = _Ostr.width() <= 0 || _Ostr.width() <= _Count
		? 0 : _Ostr.width() - _Count;
	const typename basic_ostream<_Elem, _Traits>::sentry _Ok(_Ostr);

	if (!_Ok)
		_State |= ios_base::badbit;
	else
		{	// state okay, insert characters
		_TRY_IO_BEGIN
		const ctype<_Elem>& _Ctype_fac = use_facet< ctype<_Elem> >(_Ostr.getloc());
		if ((_Ostr.flags() & ios_base::adjustfield) != ios_base::left)
			for (; 0 < _Pad; --_Pad)	// pad on left
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					{	// insertion failed, quit
					_State |= ios_base::badbit;
					break;
					}

		for (; _State == ios_base::goodbit && 0 < _Count; --_Count, ++_Val)
			if (_Traits::eq_int_type(_Traits::eof(),
				_Ostr.rdbuf()->sputc(_Ctype_fac.widen(*_Val))))
					_State |= ios_base::badbit;

		if (_State == ios_base::goodbit)
			for (; 0 < _Pad; --_Pad)	// pad on right
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					{	// insertion failed, quit
					_State |= ios_base::badbit;
					break;
					}
		_Ostr.width(0);
		_CATCH_IO_(_Ostr)
		}

	_Ostr.setstate(_State);
	return (_Ostr);
	}

template<class _Elem,
	class _Traits>
	basic_ostream<_Elem, _Traits>& operator<<(
		basic_ostream<_Elem, _Traits>& _Ostr, char _Ch)
	{	// insert a character
	ios_base::iostate _State = ios_base::goodbit;
	const typename basic_ostream<_Elem, _Traits>::sentry _Ok(_Ostr);

	if (_Ok)
		{	// state okay, insert
		const ctype<_Elem>& _Ctype_fac = use_facet< ctype<_Elem> >(_Ostr.getloc());
		streamsize _Pad = _Ostr.width() <= 1 ? 0 : _Ostr.width() - 1;

		_TRY_IO_BEGIN
		if ((_Ostr.flags() & ios_base::adjustfield) != ios_base::left)
			for (; _State == ios_base::goodbit && 0 < _Pad;
				--_Pad)	// pad on left
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					_State |= ios_base::badbit;

		if (_State == ios_base::goodbit
			&& _Traits::eq_int_type(_Traits::eof(),
				_Ostr.rdbuf()->sputc(_Ctype_fac.widen(_Ch))))
			_State |= ios_base::badbit;

		for (; _State == ios_base::goodbit && 0 < _Pad;
			--_Pad)	// pad on right
			if (_Traits::eq_int_type(_Traits::eof(),
				_Ostr.rdbuf()->sputc(_Ostr.fill())))
				_State |= ios_base::badbit;
		_CATCH_IO_(_Ostr)
		}

	_Ostr.width(0);
	_Ostr.setstate(_State);
	return (_Ostr);
	}

template<class _Traits>
	basic_ostream<char, _Traits>& operator<<(
		basic_ostream<char, _Traits>& _Ostr,
		const char *_Val)
	{	// insert NTBS into char stream
	typedef char _Elem;
	typedef basic_ostream<_Elem, _Traits> _Myos;
	ios_base::iostate _State = ios_base::goodbit;
	streamsize _Count = (streamsize)_Traits::length(_Val);	// may overflow
	streamsize _Pad = _Ostr.width() <= 0 || _Ostr.width() <= _Count
		? 0 : _Ostr.width() - _Count;
	const typename _Myos::sentry _Ok(_Ostr);

	if (!_Ok)
		_State |= ios_base::badbit;
	else
		{	// state okay, insert
		_TRY_IO_BEGIN
		if ((_Ostr.flags() & ios_base::adjustfield) != ios_base::left)
			for (; 0 < _Pad; --_Pad)	// pad on left
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					{	// insertion failed, quit
					_State |= ios_base::badbit;
					break;
					}

		if (_State == ios_base::goodbit
			&& _Ostr.rdbuf()->sputn(_Val, _Count) != _Count)
			_State |= ios_base::badbit;

		if (_State == ios_base::goodbit)
			for (; 0 < _Pad; --_Pad)	// pad on right
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					{	// insertion failed, quit
					_State |= ios_base::badbit;
					break;
					}
		_Ostr.width(0);
		_CATCH_IO_(_Ostr)
		}

	_Ostr.setstate(_State);
	return (_Ostr);
	}

template<class _Traits>
	basic_ostream<char, _Traits>& operator<<(
		basic_ostream<char, _Traits>& _Ostr, char _Ch)
	{	// insert a char into char stream
	typedef char _Elem;
	typedef basic_ostream<_Elem, _Traits> _Myos;
	ios_base::iostate _State = ios_base::goodbit;
	const typename _Myos::sentry _Ok(_Ostr);

	if (_Ok)
		{	// state okay, insert
		streamsize _Pad = _Ostr.width() <= 1 ? 0 : _Ostr.width() - 1;

		_TRY_IO_BEGIN
		if ((_Ostr.flags() & ios_base::adjustfield) != ios_base::left)
			for (; _State == ios_base::goodbit && 0 < _Pad;
				--_Pad)	// pad on left
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					_State |= ios_base::badbit;

		if (_State == ios_base::goodbit
			&& _Traits::eq_int_type(_Traits::eof(),
				_Ostr.rdbuf()->sputc(_Ch)))
			_State |= ios_base::badbit;

		for (; _State == ios_base::goodbit && 0 < _Pad;
			--_Pad)	// pad on right
			if (_Traits::eq_int_type(_Traits::eof(),
				_Ostr.rdbuf()->sputc(_Ostr.fill())))
				_State |= ios_base::badbit;
		_CATCH_IO_(_Ostr)
		}

	_Ostr.width(0);
	_Ostr.setstate(_State);
	return (_Ostr);
	}

template<class _Elem,
	class _Traits>
	basic_ostream<_Elem, _Traits>& operator<<(
		basic_ostream<_Elem, _Traits>& _Ostr, const _Elem *_Val)
	{	// insert NTCS
	typedef basic_ostream<_Elem, _Traits> _Myos;
	ios_base::iostate _State = ios_base::goodbit;
	streamsize _Count = (streamsize)_Traits::length(_Val);	// may overflow
	streamsize _Pad = _Ostr.width() <= 0 || _Ostr.width() <= _Count
		? 0 : _Ostr.width() - _Count;
	const typename _Myos::sentry _Ok(_Ostr);

	if (!_Ok)
		_State |= ios_base::badbit;
	else
		{	// state okay, insert
		_TRY_IO_BEGIN
		if ((_Ostr.flags() & ios_base::adjustfield) != ios_base::left)
			for (; 0 < _Pad; --_Pad)	// pad on left
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					{	// insertion failed, quit
					_State |= ios_base::badbit;
					break;
					}

		if (_State == ios_base::goodbit
			&& _Ostr.rdbuf()->sputn(_Val, _Count) != _Count)
			_State |= ios_base::badbit;

		if (_State == ios_base::goodbit)
			for (; 0 < _Pad; --_Pad)	// pad on right
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					{	// insertion failed, quit
					_State |= ios_base::badbit;
					break;
					}
		_Ostr.width(0);
		_CATCH_IO_(_Ostr)
		}

	_Ostr.setstate(_State);
	return (_Ostr);
	}

template<class _Elem,
	class _Traits>
	basic_ostream<_Elem, _Traits>& operator<<(
		basic_ostream<_Elem, _Traits>& _Ostr, _Elem _Ch)
	{	// insert a character
	typedef basic_ostream<_Elem, _Traits> _Myos;
	ios_base::iostate _State = ios_base::goodbit;
	const typename _Myos::sentry _Ok(_Ostr);

	if (_Ok)
		{	// state okay, insert
		streamsize _Pad = _Ostr.width() <= 1 ? 0 : _Ostr.width() - 1;

		_TRY_IO_BEGIN
		if ((_Ostr.flags() & ios_base::adjustfield) != ios_base::left)
			for (; _State == ios_base::goodbit && 0 < _Pad;
				--_Pad)	// pad on left
				if (_Traits::eq_int_type(_Traits::eof(),
					_Ostr.rdbuf()->sputc(_Ostr.fill())))
					_State |= ios_base::badbit;

		if (_State == ios_base::goodbit
			&& _Traits::eq_int_type(_Traits::eof(),
				_Ostr.rdbuf()->sputc(_Ch)))
			_State |= ios_base::badbit;

		for (; _State == ios_base::goodbit && 0 < _Pad;
			--_Pad)	// pad on right
			if (_Traits::eq_int_type(_Traits::eof(),
				_Ostr.rdbuf()->sputc(_Ostr.fill())))
				_State |= ios_base::badbit;
		_CATCH_IO_(_Ostr)
		}

	_Ostr.width(0);
	_Ostr.setstate(_State);
	return (_Ostr);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */

// EXPORTED FUNCTIONS
#include <xtree>
_STD_BEGIN

template<class _Traits>
	_Tree<_Traits>::_Tree(const value_type *_First, const value_type *_Last,
	const key_compare& _Parg, const allocator_type& _Al)
	: _Mybase(_Parg, _Al)
	{	// construct tree from [_First, _Last) array
	_Init();
	_TRY_BEGIN
	insert(_First, _Last);
	_CATCH_ALL
	_Tidy();
	_RERAISE;
	_CATCH_END
	}

template<class _Traits>
	_Tree<_Traits>::_Tree(const _Myt& _Right)
	: _Mybase(_Right.key_comp(), _Right.get_allocator())
	{	// construct tree by copying _Right
	_Init();
	_TRY_BEGIN
	_Copy(_Right);
	_CATCH_ALL
	_Tidy();
	_RERAISE;
	_CATCH_END
	}

template<class _Traits>
	typename _Tree<_Traits>::_Pairib _Tree<_Traits>::insert(const value_type& _Val)
	{	// try to insert node with value _Val
	_Nodeptr _Trynode = _Root();
	_Nodeptr _Wherenode = _Myhead;
	bool _Addleft = true;	// add to left of head if tree empty
	while (!_Isnil(_Trynode))
		{	// look for leaf to insert before (_Addleft) or after
		_Wherenode = _Trynode;
		_Addleft = _DEBUG_LT_PRED(this->comp,
			this->_Kfn(_Val), _Key(_Trynode));
		_Trynode = _Addleft ? _Left(_Trynode) : _Right(_Trynode);
		}

	if (this->_Multi)
		return (_Pairib(_Insert(_Addleft, _Wherenode, _Val), true));
	else
		{	// insert only if unique
		iterator _Where = _TREE_ITERATOR(_Wherenode);
		if (!_Addleft)
			;	// need to test if insert after is okay
		else if (_Where == begin())
			return (_Pairib(_Insert(true, _Wherenode, _Val), true));
		else
			--_Where;	// need to test if insert before is okay

		if (_DEBUG_LT_PRED(this->comp,
			_Key(_Where._Mynode()), this->_Kfn(_Val)))
			return (_Pairib(_Insert(_Addleft, _Wherenode, _Val), true));
		else
			return (_Pairib(_Where, false));
		}
	}

template<class _Traits>
	typename _Tree<_Traits>::iterator _Tree<_Traits>::insert(iterator _Where,
	const value_type& _Val)
	{	// try to insert node with value _Val using _Where as a hint

 #if _HAS_ITERATOR_DEBUGGING
	if (_Where._Mycont != this)
		_DEBUG_ERROR("map/set insert iterator outside range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	iterator _Next;

	if (size() == 0)
		return (_Insert(true, _Myhead, _Val));	// insert into empty tree
	else if (this->_Multi)
		{	// insert even if duplicate
		if (_Where == begin())
			{	// insert at beginning if before first element
			if (!_DEBUG_LT_PRED(this->comp,
				_Key(_Where._Mynode()), this->_Kfn(_Val)))
				return (_Insert(true, _Where._Mynode(), _Val));
			}
		else if (_Where == end())
			{	// insert at end if after last element
			if (!_DEBUG_LT_PRED(this->comp,
				this->_Kfn(_Val), _Key(_Rmost())))
				return (_Insert(false, _Rmost(), _Val));
			}
		else if (!_DEBUG_LT_PRED(this->comp,
			_Key(_Where._Mynode()), this->_Kfn(_Val))
			&& !_DEBUG_LT_PRED(this->comp,
				this->_Kfn(_Val), _Key((--(_Next = _Where))._Mynode())))
			{	// insert before _Where
			if (_Isnil(_Right(_Next._Mynode())))
				return (_Insert(false, _Next._Mynode(), _Val));
			else
				return (_Insert(true, _Where._Mynode(), _Val));
			}
		else if (!_DEBUG_LT_PRED(this->comp,
			this->_Kfn(_Val), _Key(_Where._Mynode()))
			&& (++(_Next = _Where) == end()
				|| !_DEBUG_LT_PRED(this->comp,
					_Key(_Next._Mynode()), this->_Kfn(_Val))))
			{	// insert after _Where
			if (_Isnil(_Right(_Where._Mynode())))
				return (_Insert(false, _Where._Mynode(), _Val));
			else
				return (_Insert(true, _Next._Mynode(), _Val));
			}
		}
	else
		{	// insert only if unique
		if (_Where == begin())
			{	// insert at beginning if before first element
			if (_DEBUG_LT_PRED(this->comp,
				this->_Kfn(_Val), _Key(_Where._Mynode())))
				return (_Insert(true, _Where._Mynode(), _Val));
			}
		else if (_Where == end())
			{	// insert at end if after last element
			if (_DEBUG_LT_PRED(this->comp,
				_Key(_Rmost()), this->_Kfn(_Val)))
				return (_Insert(false, _Rmost(), _Val));
			}
		else if (_DEBUG_LT_PRED(this->comp,
			this->_Kfn(_Val), _Key(_Where._Mynode()))
			&& _DEBUG_LT_PRED(this->comp,
				_Key((--(_Next = _Where))._Mynode()), this->_Kfn(_Val)))
			{	// insert before _Where
			if (_Isnil(_Right(_Next._Mynode())))
				return (_Insert(false, _Next._Mynode(), _Val));
			else
				return (_Insert(true, _Where._Mynode(), _Val));
			}
		else if (_DEBUG_LT_PRED(this->comp,
			_Key(_Where._Mynode()), this->_Kfn(_Val))
			&& (++(_Next = _Where) == end()
				|| _DEBUG_LT_PRED(this->comp,
					this->_Kfn(_Val), _Key(_Next._Mynode()))))
			{	// insert after _Where
			if (_Isnil(_Right(_Where._Mynode())))
				return (_Insert(false, _Where._Mynode(), _Val));
			else
				return (_Insert(true, _Next._Mynode(), _Val));
			}
		}

	return (insert(_Val).first);	// try usual insert if all else fails
	}

template<class _Traits>
	template<class _Iter>
	void _Tree<_Traits>::insert(_Iter _First, _Iter _Last)
	{	// insert [_First, _Last) one at a time

 #if _HAS_ITERATOR_DEBUGGING
	_DEBUG_RANGE(_First, _Last);
	if (_Debug_get_cont(_First) == this)
		_DEBUG_ERROR("map/set insertion overlaps range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	for (; _First != _Last; ++_First)
		insert(*_First);
	}

template<class _Traits>
	typename _Tree<_Traits>::iterator _Tree<_Traits>::erase(iterator _Where)
	{	// erase element at _Where

 #if _HAS_ITERATOR_DEBUGGING
	if (_Where._Mycont != this || _Isnil(_Where._Mynode()))
		_DEBUG_ERROR("map/set erase iterator outside range");
	_Nodeptr _Erasednode = _Where._Mynode();	// node to erase
	++_Where;	// save successor iterator for return
	_Orphan_ptr(_Erasednode);

 #else /* _HAS_ITERATOR_DEBUGGING */
	if (_Isnil(_Where._Mynode()))
		_THROW(out_of_range, "invalid map/set<T> iterator");
	_Nodeptr _Erasednode = _Where._Mynode();	// node to erase
	++_Where;	// save successor iterator for return
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_Nodeptr _Fixnode;	// the node to recolor as needed
	_Nodeptr _Fixnodeparent;	// parent of _Fixnode (which may be nil)
	_Nodeptr _Pnode = _Erasednode;

	if (_Isnil(_Left(_Pnode)))
		_Fixnode = _Right(_Pnode);	// must stitch up right subtree
	else if (_Isnil(_Right(_Pnode)))
		_Fixnode = _Left(_Pnode);	// must stitch up left subtree
	else
		{	// two subtrees, must lift successor node to replace erased
		_Pnode = _Where._Mynode();	// _Pnode is successor node
		_Fixnode = _Right(_Pnode);	// _Fixnode is its only subtree
		}

	if (_Pnode == _Erasednode)
		{	// at most one subtree, relink it
		_Fixnodeparent = _Parent(_Erasednode);
		if (!_Isnil(_Fixnode))
			_Parent(_Fixnode) = _Fixnodeparent;	// link up

		if (_Root() == _Erasednode)
			_Root() = _Fixnode;	// link down from root
		else if (_Left(_Fixnodeparent) == _Erasednode)
			_Left(_Fixnodeparent) = _Fixnode;	// link down to left
		else
			_Right(_Fixnodeparent) = _Fixnode;	// link down to right

		if (_Lmost() == _Erasednode)
			_Lmost() = _Isnil(_Fixnode)
				? _Fixnodeparent	// smallest is parent of erased node
				: _Min(_Fixnode);	// smallest in relinked subtree

		if (_Rmost() == _Erasednode)
			_Rmost() = _Isnil(_Fixnode)
				? _Fixnodeparent	// largest is parent of erased node
				: _Max(_Fixnode);	// largest in relinked subtree
		}
	else
		{	// erased has two subtrees, _Pnode is successor to erased
		_Parent(_Left(_Erasednode)) = _Pnode;	// link left up
		_Left(_Pnode) = _Left(_Erasednode);	// link successor down

		if (_Pnode == _Right(_Erasednode))
			_Fixnodeparent = _Pnode;	// successor is next to erased
		else
			{	// successor further down, link in place of erased
			_Fixnodeparent = _Parent(_Pnode);	// parent is successor's
			if (!_Isnil(_Fixnode))
				_Parent(_Fixnode) = _Fixnodeparent;	// link fix up
			_Left(_Fixnodeparent) = _Fixnode;	// link fix down
			_Right(_Pnode) = _Right(_Erasednode);	// link successor down
			_Parent(_Right(_Erasednode)) = _Pnode;	// link right up
			}

		if (_Root() == _Erasednode)
			_Root() = _Pnode;	// link down from root
		else if (_Left(_Parent(_Erasednode)) == _Erasednode)
			_Left(_Parent(_Erasednode)) = _Pnode;	// link down to left
		else
			_Right(_Parent(_Erasednode)) = _Pnode;	// link down to right

		_Parent(_Pnode) = _Parent(_Erasednode);	// link successor up
		_STD swap(_Color(_Pnode), _Color(_Erasednode));	// recolor it
		}

	if (_Color(_Erasednode) == _Black)
		{	// erasing black link, must recolor/rebalance tree
		for (; _Fixnode != _Root() && _Color(_Fixnode) == _Black;
			_Fixnodeparent = _Parent(_Fixnode))
			if (_Fixnode == _Left(_Fixnodeparent))
				{	// fixup left subtree
				_Pnode = _Right(_Fixnodeparent);
				if (_Color(_Pnode) == _Red)
					{	// rotate red up from right subtree
					_Color(_Pnode) = _Black;
					_Color(_Fixnodeparent) = _Red;
					_Lrotate(_Fixnodeparent);
					_Pnode = _Right(_Fixnodeparent);
					}

				if (_Isnil(_Pnode))
					_Fixnode = _Fixnodeparent;	// shouldn't happen
				else if (_Color(_Left(_Pnode)) == _Black
					&& _Color(_Right(_Pnode)) == _Black)
					{	// redden right subtree with black children
					_Color(_Pnode) = _Red;
					_Fixnode = _Fixnodeparent;
					}
				else
					{	// must rearrange right subtree
					if (_Color(_Right(_Pnode)) == _Black)
						{	// rotate red up from left sub-subtree
						_Color(_Left(_Pnode)) = _Black;
						_Color(_Pnode) = _Red;
						_Rrotate(_Pnode);
						_Pnode = _Right(_Fixnodeparent);
						}

					_Color(_Pnode) = _Color(_Fixnodeparent);
					_Color(_Fixnodeparent) = _Black;
					_Color(_Right(_Pnode)) = _Black;
					_Lrotate(_Fixnodeparent);
					break;	// tree now recolored/rebalanced
					}
				}
			else
				{	// fixup right subtree
				_Pnode = _Left(_Fixnodeparent);
				if (_Color(_Pnode) == _Red)
					{	// rotate red up from left subtree
					_Color(_Pnode) = _Black;
					_Color(_Fixnodeparent) = _Red;
					_Rrotate(_Fixnodeparent);
					_Pnode = _Left(_Fixnodeparent);
					}
				if (_Isnil(_Pnode))
					_Fixnode = _Fixnodeparent;	// shouldn't happen
				else if (_Color(_Right(_Pnode)) == _Black
					&& _Color(_Left(_Pnode)) == _Black)
					{	// redden left subtree with black children
					_Color(_Pnode) = _Red;
					_Fixnode = _Fixnodeparent;
					}
				else
					{	// must rearrange left subtree
					if (_Color(_Left(_Pnode)) == _Black)
						{	// rotate red up from right sub-subtree
						_Color(_Right(_Pnode)) = _Black;
						_Color(_Pnode) = _Red;
						_Lrotate(_Pnode);
						_Pnode = _Left(_Fixnodeparent);
						}

					_Color(_Pnode) = _Color(_Fixnodeparent);
					_Color(_Fixnodeparent) = _Black;
					_Color(_Left(_Pnode)) = _Black;
					_Rrotate(_Fixnodeparent);
					break;	// tree now recolored/rebalanced
					}
				}

		_Color(_Fixnode) = _Black;	// ensure stopping node is black
		}

	this->_Alnod.destroy(_Erasednode);	// destroy, free erased node
	this->_Alnod.deallocate(_Erasednode, 1);
	if (0 < _Mysize)
		--_Mysize;

	return (_Where);	// return successor iterator
	}

template<class _Traits>
	typename _Tree<_Traits>::iterator _Tree<_Traits>::erase(iterator _First, iterator _Last)
	{	// erase [_First, _Last)
	if (_First == begin() && _Last == end())
		{	// erase all
		clear();
		return (begin());
		}
	else
		{	// partial erase, one at a time
		while (_First != _Last)
			erase(_First++);
		return (_First);
		}
	}

template<class _Traits>
	typename _Tree<_Traits>::size_type _Tree<_Traits>::erase(const key_type& _Keyval)
	{	// erase and count all that match _Keyval
	_Pairii _Where = equal_range(_Keyval);
	size_type _Num = 0;
	_Distance(_Where.first, _Where.second, _Num);
	erase(_Where.first, _Where.second);
	return (_Num);
	}

template<class _Traits>
	void _Tree<_Traits>::_Copy(const _Myt& _Right)
	{	// copy entire tree from _Right
	_Root() = _Copy(_Right._Root(), _Myhead);
	_Mysize = _Right.size();
	if (!_Isnil(_Root()))
		{	// nonempty tree, look for new smallest and largest
		_Lmost() = _Min(_Root());
		_Rmost() = _Max(_Root());
		}
	else
		_Lmost() = _Myhead, _Rmost() = _Myhead;	// empty tree
	}

template<class _Traits>
	typename _Tree<_Traits>::_Nodeptr _Tree<_Traits>::_Copy(_Nodeptr _Rootnode, _Nodeptr _Wherenode)
	{	// copy entire subtree, recursively
	_Nodeptr _Newroot = _Myhead;	// point at nil node

	if (!_Isnil(_Rootnode))
		{	// copy a node, then any subtrees
		_Nodeptr _Pnode = _Buynode(_Myhead, _Wherenode, _Myhead,
			_Myval(_Rootnode), _Color(_Rootnode));
		if (_Isnil(_Newroot))
			_Newroot = _Pnode;	// memorize new root

		_TRY_BEGIN
		_Left(_Pnode) = _Copy(_Left(_Rootnode), _Pnode);
		_Right(_Pnode) = _Copy(_Right(_Rootnode), _Pnode);
		_CATCH_ALL
		_Erase(_Newroot);	// subtree copy failed, bail out
		_RERAISE;
		_CATCH_END
		}

	return (_Newroot);	// return newly constructed tree
	}

template<class _Traits>
	void _Tree<_Traits>::_Erase(_Nodeptr _Rootnode)
	{	// free entire subtree, recursively
	for (_Nodeptr _Pnode = _Rootnode; !_Isnil(_Pnode); _Rootnode = _Pnode)
		{	// free subtrees, then node
		_Erase(_Right(_Pnode));
		_Pnode = _Left(_Pnode);
		this->_Alnod.destroy(_Rootnode);	// destroy, free erased node
		this->_Alnod.deallocate(_Rootnode, 1);
		}
	}

template<class _Traits>
	typename _Tree<_Traits>::iterator _Tree<_Traits>::_Insert(bool _Addleft, _Nodeptr _Wherenode,
	const value_type& _Val)
	{	// add node with value next to _Wherenode, to left if _Addnode
	if (max_size() - 1 <= _Mysize)
		_THROW(length_error, "map/set<T> too long");
	_Nodeptr _Newnode = _Buynode(_Myhead, _Wherenode, _Myhead,
		_Val, _Red);

	++_Mysize;
	if (_Wherenode == _Myhead)
		{	// first node in tree, just set head values
		_Root() = _Newnode;
		_Lmost() = _Newnode, _Rmost() = _Newnode;
		}
	else if (_Addleft)
		{	// add to left of _Wherenode
		_Left(_Wherenode) = _Newnode;
		if (_Wherenode == _Lmost())
			_Lmost() = _Newnode;
		}
	else
		{	// add to right of _Wherenode
		_Right(_Wherenode) = _Newnode;
		if (_Wherenode == _Rmost())
			_Rmost() = _Newnode;
		}

	for (_Nodeptr _Pnode = _Newnode; _Color(_Parent(_Pnode)) == _Red; )
		if (_Parent(_Pnode) == _Left(_Parent(_Parent(_Pnode))))
			{	// fixup red-red in left subtree
			_Wherenode = _Right(_Parent(_Parent(_Pnode)));
			if (_Color(_Wherenode) == _Red)
				{	// parent has two red children, blacken both
				_Color(_Parent(_Pnode)) = _Black;
				_Color(_Wherenode) = _Black;
				_Color(_Parent(_Parent(_Pnode))) = _Red;
				_Pnode = _Parent(_Parent(_Pnode));
				}
			else
				{	// parent has red and black children
				if (_Pnode == _Right(_Parent(_Pnode)))
					{	// rotate right child to left
					_Pnode = _Parent(_Pnode);
					_Lrotate(_Pnode);
					}
				_Color(_Parent(_Pnode)) = _Black;	// propagate red up
				_Color(_Parent(_Parent(_Pnode))) = _Red;
				_Rrotate(_Parent(_Parent(_Pnode)));
				}
			}
		else
			{	// fixup red-red in right subtree
			_Wherenode = _Left(_Parent(_Parent(_Pnode)));
			if (_Color(_Wherenode) == _Red)
				{	// parent has two red children, blacken both
				_Color(_Parent(_Pnode)) = _Black;
				_Color(_Wherenode) = _Black;
				_Color(_Parent(_Parent(_Pnode))) = _Red;
				_Pnode = _Parent(_Parent(_Pnode));
				}
			else
				{	// parent has red and black children
				if (_Pnode == _Left(_Parent(_Pnode)))
					{	// rotate left child to right
					_Pnode = _Parent(_Pnode);
					_Rrotate(_Pnode);
					}
				_Color(_Parent(_Pnode)) = _Black;	// propagate red up
				_Color(_Parent(_Parent(_Pnode))) = _Red;
				_Lrotate(_Parent(_Parent(_Pnode)));
				}
			}

	_Color(_Root()) = _Black;	// root is always black
	return (_TREE_ITERATOR(_Newnode));
	}

template<class _Traits>
	typename _Tree<_Traits>::_Nodeptr _Tree<_Traits>::_Lbound(const key_type& _Keyval) const
	{	// find leftmost node not less than _Keyval
	_Nodeptr _Pnode = _Root();
	_Nodeptr _Wherenode = _Myhead;	// end() if search fails

	while (!_Isnil(_Pnode))
		if (_DEBUG_LT_PRED(this->comp, _Key(_Pnode), _Keyval))
			_Pnode = _Right(_Pnode);	// descend right subtree
		else
			{	// _Pnode not less than _Keyval, remember it
			_Wherenode = _Pnode;
			_Pnode = _Left(_Pnode);	// descend left subtree
			}

	return (_Wherenode);	// return best remembered candidate
	}

template<class _Traits>
	void _Tree<_Traits>::_Lrotate(_Nodeptr _Wherenode)
	{	// promote right node to root of subtree
	_Nodeptr _Pnode = _Right(_Wherenode);
	_Right(_Wherenode) = _Left(_Pnode);

	if (!_Isnil(_Left(_Pnode)))
		_Parent(_Left(_Pnode)) = _Wherenode;
	_Parent(_Pnode) = _Parent(_Wherenode);

	if (_Wherenode == _Root())
		_Root() = _Pnode;
	else if (_Wherenode == _Left(_Parent(_Wherenode)))
		_Left(_Parent(_Wherenode)) = _Pnode;
	else
		_Right(_Parent(_Wherenode)) = _Pnode;

	_Left(_Pnode) = _Wherenode;
	_Parent(_Wherenode) = _Pnode;
	}

template<class _Traits>
	void _Tree<_Traits>::_Rrotate(_Nodeptr _Wherenode)
	{	// promote left node to root of subtree
	_Nodeptr _Pnode = _Left(_Wherenode);
	_Left(_Wherenode) = _Right(_Pnode);

	if (!_Isnil(_Right(_Pnode)))
		_Parent(_Right(_Pnode)) = _Wherenode;
	_Parent(_Pnode) = _Parent(_Wherenode);

	if (_Wherenode == _Root())
		_Root() = _Pnode;
	else if (_Wherenode == _Right(_Parent(_Wherenode)))
		_Right(_Parent(_Wherenode)) = _Pnode;
	else
		_Left(_Parent(_Wherenode)) = _Pnode;

	_Right(_Pnode) = _Wherenode;
	_Parent(_Wherenode) = _Pnode;
	}

template<class _Traits>
	typename _Tree<_Traits>::_Nodeptr _Tree<_Traits>::_Ubound(const key_type& _Keyval) const
	{	// find leftmost node greater than _Keyval
	_Nodeptr _Pnode = _Root();
	_Nodeptr _Wherenode = _Myhead;	// end() if search fails

	while (!_Isnil(_Pnode))
		if (_DEBUG_LT_PRED(this->comp, _Keyval, _Key(_Pnode)))
			{	// _Pnode greater than _Keyval, remember it
			_Wherenode = _Pnode;
			_Pnode = _Left(_Pnode);	// descend left subtree
			}
		else
			_Pnode = _Right(_Pnode);	// descend right subtree

	return (_Wherenode);	// return best remembered candidate
	}

template<class _Traits>
	typename _Tree<_Traits>::_Nodeptr _Tree<_Traits>::_Buynode()
	{	// allocate a head/nil node
	_Nodeptr _Wherenode = this->_Alnod.allocate(1);
	int _Linkcnt = 0;

	_TRY_BEGIN
	this->_Alptr.construct(&_Left(_Wherenode), 0);
	++_Linkcnt;
	this->_Alptr.construct(&_Parent(_Wherenode), 0);
	++_Linkcnt;
	this->_Alptr.construct(&_Right(_Wherenode), 0);
	_CATCH_ALL
	if (1 < _Linkcnt)
		this->_Alptr.destroy(&_Parent(_Wherenode));
	if (0 < _Linkcnt)
		this->_Alptr.destroy(&_Left(_Wherenode));
	this->_Alnod.deallocate(_Wherenode, 1);
	_RERAISE;
	_CATCH_END
	_Color(_Wherenode) = _Black;
	_Isnil(_Wherenode) = false;
	return (_Wherenode);
	}

template<class _Traits>
	typename _Tree<_Traits>::_Nodeptr _Tree<_Traits>::_Buynode(_Nodeptr _Larg, _Nodeptr _Parg,
	_Nodeptr _Rarg, const value_type& _Val, char _Carg)
	{	// allocate a node with pointers, value, and color
	_Nodeptr _Wherenode = this->_Alnod.allocate(1);
	_TRY_BEGIN
	new (_Wherenode) _Node(_Larg, _Parg, _Rarg, _Val, _Carg);
	_CATCH_ALL
	this->_Alnod.deallocate(_Wherenode, 1);
	_RERAISE;
	_CATCH_END
	return (_Wherenode);
	}

template<class _Traits>
	void _Tree<_Traits>::_Tidy()
	{	// free all storage
	erase(begin(), end());
	this->_Alptr.destroy(&_Left(_Myhead));
	this->_Alptr.destroy(&_Parent(_Myhead));
	this->_Alptr.destroy(&_Right(_Myhead));
	this->_Alnod.deallocate(_Myhead, 1);
	_Myhead = 0, _Mysize = 0;
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */

// EXPORTED FUNCTIONS
#include <list>
_STD_BEGIN

template<class _Ty, class _Ax>
	list<_Ty, _Ax>::list(const _Myt& _Right)
	: _Mybase(_Right._Alval),
		_Myhead(_Buynode()), _Mysize(0)
	{	// construct list by copying _Right
	_TRY_BEGIN
	insert(begin(), _Right.begin(), _Right.end());
	_CATCH_ALL
	_Tidy();
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	template<class _Iter>
	void list<_Ty, _Ax>::_Construct(_Iter _First,
		_Iter _Last, input_iterator_tag)
	{	// construct list from [_First, _Last), input iterators
	_TRY_BEGIN
	insert(begin(), _First, _Last);
	_CATCH_ALL
	_Tidy();
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::_Construct_n(size_type _Count,
	const _Ty& _Val)
	{	// construct from _Count * _Val
	_TRY_BEGIN
	_Insert_n(begin(), _Count, _Val);
	_CATCH_ALL
	_Tidy();
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::resize(size_type _Newsize, _Ty _Val)
	{	// determine new length, padding with _Val elements as needed
	if (_Mysize < _Newsize)
		_Insert_n(end(), _Newsize - _Mysize, _Val);
	else
		while (_Newsize < _Mysize)
			pop_back();
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::_Insert(iterator _Where,
	const _Ty& _Val)
	{	// insert _Val at _Where

 #if _HAS_ITERATOR_DEBUGGING
	if (_Where._Mycont != this)
		_DEBUG_ERROR("list insert iterator outside range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_Nodeptr _Pnode = _Where._Mynode();
	_Nodeptr _Newnode = _Buynode(_Pnode, _Prevnode(_Pnode), _Val);
	_Incsize(1);
	_Prevnode(_Pnode) = _Newnode;
	_Nextnode(_Prevnode(_Newnode)) = _Newnode;
	}

template<class _Ty, class _Ax>
	template<class _Iter>
	void list<_Ty, _Ax>::_Insert(iterator _Where,
		_Iter _First, _Iter _Last, input_iterator_tag)
	{	// insert [_First, _Last) at _Where, input iterators
	size_type _Num = 0;

	_TRY_BEGIN
	for (; _First != _Last; ++_First, ++_Num)
		_Insert(_Where, *_First);
	_CATCH_ALL
	for (; 0 < _Num; --_Num)
		{	// undo inserts
		iterator _Before = _Where;
		erase(--_Before);
		}
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	template<class _Iter>
	void list<_Ty, _Ax>::_Insert(iterator _Where,
		_Iter _First, _Iter _Last, forward_iterator_tag)
	{	// insert [_First, _Last) at _Where, forward iterators

 #if _HAS_ITERATOR_DEBUGGING
	_DEBUG_RANGE(_First, _Last);
	if (_Debug_get_cont(_First) == this)
		_DEBUG_ERROR("list insertion overlaps range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_Iter _Next = _First;

	_TRY_BEGIN
	for (; _First != _Last; ++_First)
		_Insert(_Where, *_First);
	_CATCH_ALL
	for (; _Next != _First; ++_Next)
		{	// undo inserts
		iterator _Before = _Where;
		erase(--_Before);
		}
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	typename list<_Ty, _Ax>::iterator list<_Ty, _Ax>::erase(iterator _Where)
	{	// erase element at _Where

 #if _HAS_ITERATOR_DEBUGGING
	if (_Where._Mycont != this || _Where._Ptr == _Myhead)
		_DEBUG_ERROR("list erase iterator outside range");
	_Nodeptr _Pnode = (_Where++)._Mynode();
	_Orphan_ptr(*this, _Pnode);

 #else /* _HAS_ITERATOR_DEBUGGING */
	_Nodeptr _Pnode = (_Where++)._Mynode();
 #endif /* _HAS_ITERATOR_DEBUGGING */

	if (_Pnode != _Myhead)
		{	// not list head, safe to erase
		_Nextnode(_Prevnode(_Pnode)) = _Nextnode(_Pnode);
		_Prevnode(_Nextnode(_Pnode)) = _Prevnode(_Pnode);
		this->_Alnod.destroy(_Pnode);
		this->_Alnod.deallocate(_Pnode, 1);
		--_Mysize;
		}
	return (_Where);
	}

template<class _Ty, class _Ax>
	typename list<_Ty, _Ax>::iterator list<_Ty, _Ax>::erase(iterator _First, iterator _Last)
	{	// erase [_First, _Last)
	if (_First == begin() && _Last == end())
		clear();
	else
		while (_First != _Last)
			_First = erase(_First);
	return (_Last);
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::clear()
	{	// erase all

 #if _HAS_ITERATOR_DEBUGGING
	this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_Nodeptr _Pnext;
	_Nodeptr _Pnode = _Nextnode(_Myhead);
	_Nextnode(_Myhead) = _Myhead;
	_Prevnode(_Myhead) = _Myhead;
	_Mysize = 0;

	for (; _Pnode != _Myhead; _Pnode = _Pnext)
		{	// delete an element
		_Pnext = _Nextnode(_Pnode);
		this->_Alnod.destroy(_Pnode);
		this->_Alnod.deallocate(_Pnode, 1);
		}
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::splice(iterator _Where,
	_Myt& _Right, iterator _First, iterator _Last)
	{	// splice _Right [_First, _Last) at _Where
	if (_First != _Last && (this != &_Right || _Where != _Last))
		{	// worth splicing, do it
		size_type _Count = 0;
		if (this == &_Right)
			;	// just rearrange this list
		else if (_First == _Right.begin() && _Last == _Right.end())
			_Count = _Right._Mysize;	// splice in whole list
		else
			_Distance(_First, _Last, _Count);	// splice in partial list
		_Splice(_Where, _Right, _First, _Last, _Count);
		}
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::remove(const _Ty& _Val)
	{	// erase each element matching _Val
	iterator _Last = end();
	for (iterator _First = begin(); _First != _Last; )
		if (*_First == _Val)
			_First = erase(_First);
		else
			++_First;
	}

template<class _Ty, class _Ax>
	template<class _Pr1>
	void list<_Ty, _Ax>::remove_if(_Pr1 _Pred)
	{	// erase each element satisfying _Pr1
	iterator _Last = end();
	for (iterator _First = begin(); _First != _Last; )
		if (_Pred(*_First))
			_First = erase(_First);
		else
			++_First;
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::unique()
	{	// erase each element matching previous
	if (2 <= _Mysize)
		{	// worth doing
		iterator _First = begin();
		iterator _After = _First;
		for (++_After; _After != end(); )
			if (*_First == *_After)
				_After = erase(_After);
			else
				_First = _After++;
		}
	}

template<class _Ty, class _Ax>
	template<class _Pr2>
	void list<_Ty, _Ax>::unique(_Pr2 _Pred)
	{	// erase each element satisfying _Pred with previous
	if (2 <= _Mysize)
		{	// worth doing
		iterator _First = begin();
		iterator _After = _First;
		for (++_After; _After != end(); )
			if (_Pred(*_First, *_After))
				_After = erase(_After);
			else
				_First = _After++;
		}
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::merge(_Myt& _Right)
	{	// merge in elements from _Right, both ordered by operator<
	if (&_Right != this)
		{	// safe to merge, do it
		iterator _First1 = begin(), _Last1 = end();
		iterator _First2 = _Right.begin(), _Last2 = _Right.end();
		_DEBUG_ORDER(_First1, _Last1);
		_DEBUG_ORDER(_First2, _Last2);

		while (_First1 != _Last1 && _First2 != _Last2)
			if (_DEBUG_LT(*_First2, *_First1))
				{	// splice in an element from _Right
				iterator _Mid2 = _First2;
				_Splice(_First1, _Right, _First2, ++_Mid2, 1);
				_First2 = _Mid2;
				}
			else
				++_First1;

		if (_First2 != _Last2)
			_Splice(_Last1, _Right, _First2, _Last2,
				_Right._Mysize);	// splice remainder of _Right
		}
	}

template<class _Ty, class _Ax>
	template<class _Pr3>
	void list<_Ty, _Ax>::merge(_Myt& _Right, _Pr3 _Pred)
	{	// merge in elements from _Right, both ordered by _Pred
	if (&_Right != this)
		{	// safe to merge, do it
		iterator _First1 = begin(), _Last1 = end();
		iterator _First2 = _Right.begin(), _Last2 = _Right.end();
		_DEBUG_ORDER_PRED(_First1, _Last1, _Pred);
		_DEBUG_ORDER_PRED(_First2, _Last2, _Pred);

		while (_First1 != _Last1 && _First2 != _Last2)
			if (_DEBUG_LT_PRED(_Pred, *_First2, *_First1))
				{	// splice in an element from _Right
				iterator _Mid2 = _First2;
				_Splice(_First1, _Right, _First2, ++_Mid2, 1);
				_First2 = _Mid2;
				}
			else
				++_First1;

		if (_First2 != _Last2)
			_Splice(_Last1, _Right, _First2, _Last2,
				_Right._Mysize);	// splice remainder of _Right
		}
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::sort()
	{	// order sequence, using operator<
	if (2 <= _Mysize)
		{	// worth sorting, do it
		const size_t _MAXBINS = 25;
		_Myt _Templist(this->_Alval), _Binlist[_MAXBINS + 1];
		size_t _Maxbin = 0;

		while (!empty())
			{	// sort another element, using bins
			_Templist.splice(_Templist.begin(), *this, begin());
			size_t _Bin;

			for (_Bin = 0; _Bin < _Maxbin && !_Binlist[_Bin].empty();
				++_Bin)
				{	// merge into ever larger bins
				_Binlist[_Bin].merge(_Templist);
				_Binlist[_Bin].swap(_Templist);
				}

			if (_Bin == _MAXBINS)
				_Binlist[_Bin - 1].merge(_Templist);
			else
				{	// spill to new bin, while they last
				_Binlist[_Bin].swap(_Templist);
				if (_Bin == _Maxbin)
					++_Maxbin;
				}
			}

		for (size_t _Bin = 1; _Bin < _Maxbin; ++_Bin)
			_Binlist[_Bin].merge(_Binlist[_Bin - 1]);	// merge up
		swap(_Binlist[_Maxbin - 1]);	// replace from last bin
		}
	}

template<class _Ty, class _Ax>
	template<class _Pr3>
	void list<_Ty, _Ax>::sort(_Pr3 _Pred)
	{	// order sequence, using _Pred
	if (2 <= _Mysize)
		{	// worth sorting, do it
		const size_t _MAXBINS = 25;
		_Myt _Templist(this->_Alval), _Binlist[_MAXBINS + 1];
		size_t _Maxbin = 0;

		while (!empty())
			{	// sort another element, using bins
			_Templist.splice(_Templist.begin(), *this, begin());
			size_t _Bin;

			for (_Bin = 0; _Bin < _Maxbin && !_Binlist[_Bin].empty();
				++_Bin)
				{	// merge into ever larger bins
				_Binlist[_Bin].merge(_Templist, _Pred);
				_Binlist[_Bin].swap(_Templist);
				}

			if (_Bin == _MAXBINS)
				_Binlist[_Bin - 1].merge(_Templist, _Pred);
			else
				{	// spill to new bin, while they last
				_Binlist[_Bin].swap(_Templist);
				if (_Bin == _Maxbin)
					++_Maxbin;
				}
			}

		for (size_t _Bin = 1; _Bin < _Maxbin; ++_Bin)
			_Binlist[_Bin].merge(_Binlist[_Bin - 1],
				_Pred);	// merge up
		swap(_Binlist[_Maxbin - 1]);	// replace with last bin
		}
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::reverse()
	{	// reverse sequence
	if (2 <= _Mysize)
		{	// worth doing
		iterator _Last = end();
		for (iterator _Next = ++begin(); _Next != _Last; )
			{	// move next element to beginning
			iterator _Before = _Next;
			_Splice(begin(), *this, _Before, ++_Next, 1);
			}
		}
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::_Splice(iterator _Where,
	_Myt& _Right, iterator _First, iterator _Last, size_type _Count)
	{	// splice _Right [_First, _Last) before _Where

 #if _HAS_ITERATOR_DEBUGGING
	if (_Where._Mycont != this)
		_DEBUG_ERROR("list splice iterator outside range");
	if (this->_Alval == _Right._Alval)
		{	// same allocator, just relink
		if (0 < _Count)	// 0 ==> don't invalidate, even if _First != _Last
			for (iterator _Next = _First; _Next != _Last; )
				_Orphan_ptr(_Right, (_Next++)._Ptr);

 #else /* _HAS_ITERATOR_DEBUGGING */
	if (this->_Alval == _Right._Alval)
		{	// same allocator, just relink
 #endif /* _HAS_ITERATOR_DEBUGGING */

		if (this != &_Right)
			{	// splicing from another list, adjust counts
			_Incsize(_Count);
			_Right._Mysize -= _Count;
			}
		_Nextnode(_Prevnode(_First._Mynode())) = _Last._Mynode();
		_Nextnode(_Prevnode(_Last._Mynode())) = _Where._Mynode();
		_Nextnode(_Prevnode(_Where._Mynode())) = _First._Mynode();
		_Nodeptr _Pnode = _Prevnode(_Where._Mynode());
		_Prevnode(_Where._Mynode()) = _Prevnode(_Last._Mynode());
		_Prevnode(_Last._Mynode()) = _Prevnode(_First._Mynode());
		_Prevnode(_First._Mynode()) = _Pnode;
		}
	else
		{	// different allocator, copy nodes then erase source
		insert(_Where, _First, _Last);
		_Right.erase(_First, _Last);
		}
		}

template<class _Ty, class _Ax>
	typename list<_Ty, _Ax>::_Nodeptr list<_Ty, _Ax>::_Buynode()
	{	// allocate a head node and set links
	_Nodeptr _Pnode = this->_Alnod.allocate(1);
	int _Linkcnt = 0;

	_TRY_BEGIN
	this->_Alptr.construct(&_Nextnode(_Pnode), _Pnode);
	++_Linkcnt;
	this->_Alptr.construct(&_Prevnode(_Pnode), _Pnode);
	_CATCH_ALL
	if (0 < _Linkcnt)
		this->_Alptr.destroy(&_Nextnode(_Pnode));
	this->_Alnod.deallocate(_Pnode, 1);
	_RERAISE;
	_CATCH_END
	return (_Pnode);
	}

template<class _Ty, class _Ax>
	typename list<_Ty, _Ax>::_Nodeptr list<_Ty, _Ax>::_Buynode(_Nodeptr _Next,
	_Nodeptr _Prev, const _Ty& _Val)
	{	// allocate a node and set links and value
	_Nodeptr _Pnode = this->_Alnod.allocate(1);
	_TRY_BEGIN
	this->_Alptr.construct(&_Nextnode(_Pnode), _Next);
	this->_Alptr.construct(&_Prevnode(_Pnode), _Prev);
	this->_Alval.construct(&_Myval(_Pnode), _Val);
	_CATCH_ALL
	this->_Alnod.deallocate(_Pnode, 1);
	_RERAISE;
	_CATCH_END
	return (_Pnode);
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::_Tidy()
	{	// free all storage
	clear();
	this->_Alptr.destroy(&_Nextnode(_Myhead));
	this->_Alptr.destroy(&_Prevnode(_Myhead));
	this->_Alnod.deallocate(_Myhead, 1);
	_Myhead = 0;
	}

template<class _Ty, class _Ax>
	void list<_Ty, _Ax>::_Insert_n(iterator _Where,
	size_type _Count, const _Ty& _Val)
	{	// insert _Count * _Val at _Where
	size_type _Countsave = _Count;

	_TRY_BEGIN
	for (; 0 < _Count; --_Count)
		_Insert(_Where, _Val);
	_CATCH_ALL
	for (; _Count < _Countsave; ++_Count)
		{	// undo inserts
		iterator _Before = _Where;
		erase(--_Before);
		}
	_RERAISE;
	_CATCH_END
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */

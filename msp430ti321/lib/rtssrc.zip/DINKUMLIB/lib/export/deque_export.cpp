// EXPORTED FUNCTIONS
#include <deque>
_STD_BEGIN

template<class _Ty, class _Ax>
	deque<_Ty, _Ax>& deque<_Ty, _Ax>::operator=(const _Myt& _Right)
	{	// assign _Right
	if (this == &_Right)
		;
	else if (_Right._Mysize == 0)
		clear();
	else if (_Right._Mysize <= _Mysize)
		{	// new sequence not longer, assign elements and erase unused
		iterator _Mid = copy(_Right.begin(), _Right.end(), begin());
		erase(_Mid, end());
		}
	else
		{	// new sequence longer, assign elements and append rest
		const_iterator _Mid = _Right.begin() + _Mysize;
		copy(_Right.begin(), _Mid, begin());
		insert(end(), _Mid, _Right.end());
		}
	return (*this);
	}

template<class _Ty, class _Ax>
	void deque<_Ty, _Ax>::push_front(const _Ty& _Val)
	{	// insert element at beginning

 #if _HAS_ITERATOR_DEBUGGING
	this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

	if (_Myoff % _DEQUESIZ == 0
		&& _Mapsize <= (_Mysize + _DEQUESIZ) / _DEQUESIZ)
		_Growmap(1);
	size_type _Newoff = _Myoff != 0 ? _Myoff
		: _Mapsize * _DEQUESIZ;
	size_type _Block = --_Newoff / _DEQUESIZ;
	if (_Map[_Block] == 0)
		_Map[_Block] = this->_Alval.allocate(_DEQUESIZ);
	this->_Alval.construct(_Map[_Block] + _Newoff % _DEQUESIZ, _Val);
	_Myoff = _Newoff;
	++_Mysize;
	}

template<class _Ty, class _Ax>
	void deque<_Ty, _Ax>::pop_front()
	{	// erase element at beginning

 #if _HAS_ITERATOR_DEBUGGING
	_Orphan_off(_Myoff);
 #endif /* _HAS_ITERATOR_DEBUGGING */

	if (!empty())
		{	// something to erase, do it
		size_type _Block = _Myoff / _DEQUESIZ;
		this->_Alval.destroy(_Map[_Block] + _Myoff % _DEQUESIZ);
		if (_Mapsize * _DEQUESIZ <= ++_Myoff)
			_Myoff = 0;
		if (--_Mysize == 0)
			_Myoff = 0;
		}
	}

template<class _Ty, class _Ax>
	void deque<_Ty, _Ax>::push_back(const _Ty& _Val)
	{	// insert element at end

 #if _HAS_ITERATOR_DEBUGGING
	this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

	if ((_Myoff + _Mysize) % _DEQUESIZ == 0
		&& _Mapsize <= (_Mysize + _DEQUESIZ) / _DEQUESIZ)
		_Growmap(1);
	size_type _Newoff = _Myoff + _Mysize;
	size_type _Block = _Newoff / _DEQUESIZ;
	if (_Mapsize <= _Block)
		_Block -= _Mapsize;
	if (_Map[_Block] == 0)
		_Map[_Block] = this->_Alval.allocate(_DEQUESIZ);
	this->_Alval.construct(_Map[_Block] + _Newoff % _DEQUESIZ, _Val);
	++_Mysize;
	}

template<class _Ty, class _Ax>
	void deque<_Ty, _Ax>::pop_back()
	{	// erase element at end

 #if _HAS_ITERATOR_DEBUGGING
	_Orphan_off(_Myoff + _Mysize - 1);
 #endif /* _HAS_ITERATOR_DEBUGGING */

	if (!empty())
		{	// something to erase, do it
		size_type _Newoff = _Mysize + _Myoff - 1;
		size_type _Block = _Newoff / _DEQUESIZ;
		if (_Mapsize <= _Block)
			_Block -= _Mapsize;
		this->_Alval.destroy(_Map[_Block] + _Newoff % _DEQUESIZ);
		if (--_Mysize == 0)
			_Myoff = 0;
		}
	}

template<class _Ty, class _Ax>
	typename deque<_Ty, _Ax>::iterator deque<_Ty, _Ax>::insert(iterator _Where, const _Ty& _Val)
	{	// insert _Val at _Where
	if (_Where == begin())
		{	// insert at front
		push_front(_Val);
		return (begin());
		}
	else if (_Where == end())
		{	// insert at back
		push_back(_Val);
		return (end() - 1);
		}
	else
		{	// insert inside sequence
		iterator _Mid;
		size_type _Off = _Where - begin();
		_Ty _Tmp = _Val;	// in case _Val is in sequence

 #if _HAS_ITERATOR_DEBUGGING
	if (_Mysize < _Off)
		_DEBUG_ERROR("deque insert iterator outside range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

		if (_Off < _Mysize / 2)
			{	// closer to front, push to front then copy
			push_front(front());
			_Mid = begin() + _Off;
			copy(begin() + 2, _Mid + 1, begin() + 1);
			}
		else
			{	// closer to back, push to back then copy
			push_back(back());
			_Mid = begin() + _Off;
			copy_backward(_Mid, end() - 2, end() - 1);
			}

		*_Mid = _Tmp;	// store inserted value
		return (_Mid);
		}
	}

template<class _Ty, class _Ax>
	template<class _It>
	void deque<_Ty, _Ax>::_Insert(iterator _Where,
		_It _First, _It _Last, bidirectional_iterator_tag)
	{	// insert [_First, _Last) at _Where, bidirectional iterators
	size_type _Off = _Where - begin();

 #if _HAS_ITERATOR_DEBUGGING
	if (_Mysize < _Off)
		_DEBUG_ERROR("deque insert iterator outside range");
	_DEBUG_RANGE(_First, _Last);
	if (_Debug_get_cont(_First) == this)
		_DEBUG_ERROR("deque insertion overlaps range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	size_type _Rem = _Mysize - _Off;
	size_type _Oldsize = _Mysize;
	size_type _Count = 0;
	_Distance(_First, _Last, _Count);
	size_type _Num;

	if (_Off < _Rem)
		{	// closer to front
		_TRY_BEGIN
		if (_Off < _Count)
			{	// insert longer than prefix
			_It _Mid = _First;
			advance(_Mid, _Count - _Off);

			for (_It _Next = _Mid; _First != _Next; )
				push_front(*--_Next);	// push head of insert
			for (_Num = _Off; 0 < _Num; --_Num)
				push_front(begin()[_Count - 1]);	// push prefix
			copy(_Mid, _Last, begin() + _Count);	// copy rest of insert
			}
		else
			{	// insert not longer than prefix
			for (_Num = _Count; 0 < _Num; --_Num)
				push_front(begin()[_Count - 1]);	// push part of prefix

			iterator _Mid = begin() + _Count;
			copy(_Mid + _Count, _Mid + _Off, _Mid);	// copy rest of prefix
			copy(_First, _Last, begin() + _Off);	// copy in insert
			}
		_CATCH_ALL
		for (; _Oldsize < _Mysize; )
			pop_front();	// restore old size, at least
		_RERAISE;
		_CATCH_END
		}
	else
		{	// closer to back
		_TRY_BEGIN
		if (_Rem < _Count)
			{	// insert longer than suffix
			_It _Mid = _First;
			advance(_Mid, _Rem);

			for (_It _Next = _Mid; _Next != _Last; ++_Next)
				push_back(*_Next);	// push tail of insert
			for (_Num = 0; _Num < _Rem; ++_Num)
				push_back(begin()[_Off + _Num]);	// push suffix

			copy(_First, _Mid, begin() + _Off);	// copy rest of insert
			}
		else
			{	// insert not longer than suffix
			for (_Num = 0; _Num < _Count; ++_Num)
				push_back(begin()[_Off + _Rem
					- _Count + _Num]);	// push part of suffix

			iterator _Mid = begin() + _Off;
			copy_backward(_Mid, _Mid + _Rem - _Count,
				_Mid + _Rem);	// copy rest of prefix
			copy(_First, _Last, _Mid);	// copy in values
			}
		_CATCH_ALL
		for (; _Oldsize < _Mysize; )
			pop_back();	// restore old size, at least
		_RERAISE;
		_CATCH_END
		}
	}

template<class _Ty, class _Ax>
	typename deque<_Ty, _Ax>::iterator deque<_Ty, _Ax>::erase(iterator _First, iterator _Last)
	{	// erase [_First, _Last)

 #if _HAS_ITERATOR_DEBUGGING
	if (_Last < _First
		|| _First < begin() || end() < _Last)
		_DEBUG_ERROR("deque erase iterator outside range");
	_DEBUG_RANGE(_First, _Last);

	size_type _Off = _First - begin();
	size_type _Count = _Last - _First;
	bool _Moved = 0 < _Off && _Off + _Count < _Mysize;

 #else /* _HAS_ITERATOR_DEBUGGING */
	size_type _Off = _First - begin();
	size_type _Count = _Last - _First;
 #endif /* _HAS_ITERATOR_DEBUGGING */

	if (_Off < (size_type)(end() - _Last))
		{	// closer to front
		copy_backward(begin(), _First, _Last);	// copy over hole
		for (; 0 < _Count; --_Count)
			pop_front();	// pop copied elements
		}
	else
		{	// closer to back
		copy(_Last, end(), _First);	// copy over hole
		for (; 0 < _Count; --_Count)
			pop_back();	// pop copied elements
		}

 #if _HAS_ITERATOR_DEBUGGING
	if (_Moved)
		this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

	return (begin() + _Off);
	}

template<class _Ty, class _Ax>
	void deque<_Ty, _Ax>::_Insert_n(iterator _Where,
	size_type _Count, const _Ty& _Val)
	{	// insert _Count * _Val at _Where
	iterator _Mid;
	size_type _Num;
	size_type _Off = _Where - begin();
	size_type _Rem = _Mysize - _Off;
	size_type _Oldsize = _Mysize;

 #if _HAS_ITERATOR_DEBUGGING
	if (_Mysize < _Off)
		_DEBUG_ERROR("deque insert iterator outside range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	if (_Off < _Rem)
		{	// closer to front
		_TRY_BEGIN
		if (_Off < _Count)
			{	// insert longer than prefix
			for (_Num = _Count - _Off; 0 < _Num; --_Num)
				push_front(_Val);	// push excess values
			for (_Num = _Off; 0 < _Num; --_Num)
				push_front(begin()[_Count - 1]);	// push prefix

			_Mid = begin() + _Count;
			fill(_Mid, _Mid + _Off, _Val);	// fill in rest of values
			}
		else
			{	// insert not longer than prefix
			for (_Num = _Count; 0 < _Num; --_Num)
				push_front(begin()[_Count - 1]);	// push part of prefix

			_Mid = begin() + _Count;
			_Ty _Tmp = _Val;	// in case _Val is in sequence
			copy(_Mid + _Count, _Mid + _Off, _Mid);	// copy rest of prefix
			fill(begin() + _Off, _Mid + _Off, _Tmp);	// fill in values
			}
		_CATCH_ALL
		for (; _Oldsize < _Mysize; )
			pop_front();	// restore old size, at least
		_RERAISE;
		_CATCH_END
		}
	else
		{		// closer to back
		_TRY_BEGIN
		if (_Rem < _Count)
			{	// insert longer than suffix
			for (_Num = _Count - _Rem; 0 < _Num; --_Num)
				push_back(_Val);	// push excess values
			for (_Num = 0; _Num < _Rem; ++_Num)
				push_back(begin()[_Off + _Num]);	// push suffix

			_Mid = begin() + _Off;
			fill(_Mid, _Mid + _Rem, _Val);	// fill in rest of values
			}
		else
			{	// insert not longer than prefix
			for (_Num = 0; _Num < _Count; ++_Num)
				push_back(begin()[_Off + _Rem
					- _Count + _Num]);	// push part of prefix

			_Mid = begin() + _Off;
			_Ty _Tmp = _Val;	// in case _Val is in sequence
			copy_backward(_Mid, _Mid + _Rem - _Count,
				_Mid + _Rem);	// copy rest of prefix
			fill(_Mid, _Mid + _Count, _Tmp);	// fill in values
			}
		_CATCH_ALL
		for (; _Oldsize < _Mysize; )
			pop_back();	// restore old size, at least
		_RERAISE;
		_CATCH_END
		}
	}

template<class _Ty, class _Ax>
	void deque<_Ty, _Ax>::_Growmap(size_type _Count)
	{	// grow map by _Count pointers
	if (max_size() / _DEQUESIZ - _Mapsize < _Count)
		_Xlen();	// result too long

	size_type _Inc = _Mapsize / 2;	// try to grow by 50%
	if (_Inc < _DEQUEMAPSIZ)
		_Inc = _DEQUEMAPSIZ;
	if (_Count < _Inc && _Mapsize <= max_size() / _DEQUESIZ - _Inc)
		_Count = _Inc;
	size_type _Myboff = _Myoff / _DEQUESIZ;
	_Mapptr _Newmap = this->_Almap.allocate(_Mapsize + _Count);
	_Mapptr _Myptr = _Newmap + _Myboff;

	_Myptr = _Uninitialized_copy(_Map + _Myboff,
		_Map + _Mapsize, _Myptr, this->_Almap);	// copy initial to end
	if (_Myboff <= _Count)
		{	// increment greater than offset of initial block
		_Myptr = _Uninitialized_copy(_Map,
			_Map + _Myboff, _Myptr, this->_Almap);	// copy rest of old
		_Uninitialized_fill_n(_Myptr, _Count - _Myboff,
			(_Tptr)0, this->_Almap);	// clear suffix of new
		_Uninitialized_fill_n(_Newmap, _Myboff,
			(_Tptr)0, this->_Almap);	// clear prefix of new
		}
	else
		{	// increment not greater than offset of initial block
		_Uninitialized_copy(_Map,
			_Map + _Count, _Myptr, this->_Almap);	// copy more old
		_Myptr = _Uninitialized_copy(_Map + _Count,
			_Map + _Myboff, _Newmap, this->_Almap);	// copy rest of old
		_Uninitialized_fill_n(_Myptr, _Count,
			(_Tptr)0, this->_Almap);	// clear rest to initial block
		}

	_Destroy_range(_Map + _Myboff, _Map + _Mapsize, this->_Almap);
	this->_Almap.deallocate(_Map, _Mapsize);	// free storage for old

	_Map = _Newmap;	// point at new
	_Mapsize += _Count;
	}

template<class _Ty, class _Ax>
	void deque<_Ty, _Ax>::_Tidy()
	{	// free all storage
	while (!empty())
		pop_back();
	for (size_type _Count = _Mapsize; 0 < _Count; )
		{	// free storage for a block and destroy pointer
		if (*(_Map + --_Count) != 0)
			this->_Alval.deallocate(*(_Map + _Count), _DEQUESIZ);
		this->_Almap.destroy(_Map + _Count);
		}

	this->_Almap.deallocate(_Map, _Mapsize);	// free storage for map
	_Mapsize = 0;
	_Map = 0;
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */

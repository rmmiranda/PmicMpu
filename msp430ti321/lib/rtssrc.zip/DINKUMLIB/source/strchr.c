/* strchr function */
#if defined(__TI_COMPILER_VERSION__)
#undef  _INLINE
#define _STRING_IMPLEMENTATION
#define _STRCHR
#include <string.h>
#else /* defined(__TI_COMPILER_VERSION__) */
#include <string.h>
_STD_BEGIN

_Const_return char *(strchr)(const char *s, int c)
	{	/* find first occurrence of c in char s[] */
	const char ch = (char)c;

	for (; *s != ch; ++s)
		if (*s == '\0')
			return (0);
	return ((char *)s);
	}
_STD_END
#endif /* defined(__TI_COMPILER_VERSION__) */
/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */

// newaop2 -- operator new[](size_t, const nothrow_t&) REPLACEABLE
#include <new>

void *operator new[](_CSTD size_t count, const _STD nothrow_t& x)
	_THROW0()
	{	// try to allocate count bytes for an array
	return (operator new(count, x));
	}

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */

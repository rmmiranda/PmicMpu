// newop operator new(size_t) REPLACEABLE
#include <cstdlib>
#include <new>

void *operator new(_CSTD size_t count) _THROW1(_XSTD bad_alloc)
	{	// try to allocate count bytes
	void *p;
	while ((p = _CSTD malloc(count)) == 0)
		if (_STD _New_hand == 0)
			{	// report no memory
#if defined(__TI_COMPILER_VERSION__)
			static const _DATA_ACCESS _XSTD bad_alloc nomem;
#else
			static const _XSTD bad_alloc nomem;
#endif /* defined(__TI_COMPILER_VERSION__) */
			_RAISE(nomem);
			}
		else
			(*_STD _New_hand)();	// call new handler and retry
	return (p);
	}

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */

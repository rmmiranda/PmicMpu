/* string.h standard header */
#ifndef _STRING
#define _STRING
#ifndef _YVALS
 #include <yvals.h>
#endif /* _YVALS */

#if defined(_OPTIMIZE_FOR_SPACE) && (defined(__TMS470__)       ||\
				     defined(__TMS320C2000__)  ||\
                                     defined(__MSP430__))
#define _OPT_IDECL
#else
#define _OPT_IDECL	_IDECL
#endif

_C_STD_BEGIN

		/* macros */
#ifndef NULL
 #define NULL	_NULL
#endif /* NULL */

		/* type definitions */

 #if !defined(_SIZE_T) && !defined(_SIZET) \
	&& !defined(_BSD_SIZE_T_DEFINED_)
  #define _SIZE_T
  #define _SIZET
  #define _BSD_SIZE_T_DEFINED_
  #define _STD_USING_SIZE_T
typedef _Sizet size_t;
 #endif /* !defined(_SIZE_T) etc. */

		/* declarations */
_C_LIB_DECL
#if defined(__TI_COMPILER_VERSION__)
_OPT_IDECL int memcmp(const void *, const void *, size_t);
#else
int memcmp(const void *, const void *, size_t);
#endif /* defined(__TI_COMPILER_VERSION__) */

void *memcpy(void *_Restrict, const void *_Restrict, size_t);

_OPT_IDECL void *memset(void *, int, size_t);

#if defined(__TI_COMPILER_VERSION__)
_OPT_IDECL char *strcat(char *_Restrict, const char *_Restrict);
_OPT_IDECL int strcmp(const char *, const char *);
_OPT_IDECL char *strcpy(char *_Restrict, const char *_Restrict);
_OPT_IDECL size_t strlen(const char *);
#else
char *strcat(char *_Restrict, const char *_Restrict);
int strcmp(const char *, const char *);
char *strcpy(char *_Restrict, const char *_Restrict);
size_t strlen(const char *);
#endif

void *memmove(void *, const void *, size_t);
int strcoll(const char *, const char *);
size_t strcspn(const char *, const char *);
char *strerror(int);

#if defined(__TI_COMPILER_VERSION__)
_OPT_IDECL char *strncat(char *_Restrict, const char *_Restrict, size_t);
_OPT_IDECL int strncmp(const char *, const char *, size_t);
_OPT_IDECL char *strncpy(char *_Restrict, const char *_Restrict, size_t);
#else
char *strncat(char *_Restrict, const char *_Restrict, size_t);
int strncmp(const char *, const char *, size_t);
char *strncpy(char *_Restrict, const char *_Restrict, size_t);
#endif /* defined(__TI_COMPILER_VERSION__) */

size_t strspn(const char *, const char *);
char *strtok(char *_Restrict, const char *_Restrict);
size_t strxfrm(char *_Restrict, const char *_Restrict, size_t);

 #if _ADDED_C_LIB
char *strdup(const char *);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);
char *strtok_r(char *, const char *, char **);
 #endif /* _ADDED_C_LIB */


_END_C_LIB_DECL

 #if defined(__cplusplus) && !defined(_NO_CPP_INLINES)
		// INLINES AND OVERLOADS, for C++
 #define _Const_return const

_C_LIB_DECL
#if defined(__TI_COMPILER_VERSION__)
_OPT_IDECL const char *strchr(const char *, int);
#else
const char *strchr(const char *, int);
#endif /* defined(__TI_COMPILER_VERSION__) */

const char *strpbrk(const char *, const char *);

#if defined(__TI_COMPILER_VERSION__)
_OPT_IDECL const char *strrchr(const char *, int);
#else
const char *strrchr(const char *, int);
#endif /* defined(__TI_COMPILER_VERSION__) */

const char *strstr(const char *, const char *);
_END_C_LIB_DECL

inline char *strchr(char *_Str, int _Ch)
	{	// call with const first argument
	return ((char *)_CSTD strchr((const char *)_Str, _Ch));
	}

inline char *strpbrk(char *_Str1, const char *_Str2)
	{	// call with const first argument
	return ((char *)_CSTD strpbrk((const char *)_Str1, _Str2));
	}

inline char *strrchr(char *_Str, int _Ch)
	{	// call with const first argument
	return ((char *)_CSTD strrchr((const char *)_Str, _Ch));
	}

inline char *strstr(char *_Str1, const char *_Str2)
	{	// call with const first argument
	return ((char *)_CSTD strstr((const char *)_Str1, _Str2));
	}

 #else /* defined(__cplusplus) && !defined(_NO_CPP_INLINES)*/
_C_LIB_DECL
 #define _Const_return
#if defined(__TI_COMPILER_VERSION__)
_OPT_IDECL char *strchr(const char *, int);
_OPT_IDECL char *strrchr(const char *, int);
#else
char *strchr(const char *, int);
char *strrchr(const char *, int);
#endif /* defined(__TI_COMPILER_VERSION__) */
char *strpbrk(const char *, const char *);
char *strstr(const char *, const char *);
_END_C_LIB_DECL
 #endif /* defined(__cplusplus) && !defined(_NO_CPP_INLINES) */

 #ifndef _MEMCHR
//  #define _MEMCHR

  #if defined(__cplusplus) && !defined(_NO_CPP_INLINES)
_C_LIB_DECL
#if defined(__TI_COMPILER_VERSION__)
_OPT_IDECL void *memchr(const void *, int, size_t);
#else
const void *memchr(const void *, int, size_t);
#endif /* defined(__TI_COMPILER_VERSION__) */
_END_C_LIB_DECL

inline  void *memchr(void *_Str, int _Ch, size_t _Num)
	{	// call with const first argument
	return ((void *)_CSTD memchr((const void *)_Str, _Ch, _Num));
	}
 

  #else /* defined(__cplusplus) && !defined(_NO_CPP_INLINES) */
_C_LIB_DECL
#if defined(__TI_COMPILER_VERSION__)
_OPT_IDECL void *memchr(const void *, int, size_t);
#else
void *memchr(const void *, int, size_t);
#endif /* defined(__TI_COMPILER_VERSION__) */
_END_C_LIB_DECL
  #endif /* defined(__cplusplus) && !defined(_NO_CPP_INLINES) */

 #endif /* _MEMCHR */

#if defined(__TI_COMPILER_VERSION__)

#if defined(_INLINE) || defined(_STRING_IMPLEMENTATION)

#if (defined(_STRING_IMPLEMENTATION) ||                                 \
     !(defined(_OPTIMIZE_FOR_SPACE) && (defined(__TMS470__) || 		\
					defined(__TMS320C2000__)  ||    \
                                        defined(__MSP430__))))
   
#if (defined(_OPTIMIZE_FOR_SPACE) && (defined(__TMS470__) || 		\
				      defined(__TMS320C2000__) ||       \
                                      defined(__MSP430__)))
#define _OPT_IDEFN
#else
#define _OPT_IDEFN	_IDEFN
#endif

#if defined(_INLINE) || defined(_STRLEN)
_OPT_IDEFN  size_t (strlen)(const char *s)
	{	/* find length of s[] */
	const char *sc;

	for (sc = s; *sc != '\0'; ++sc)
		;
	return (sc - s);
	}
#endif /* _INLINE || _STRLEN */

#if defined(_INLINE) || defined(_STRCPY)
_OPT_IDEFN char *(strcpy)(char *_Restrict s1, const char *_Restrict s2)
	{	/* copy char s2[] to s1[] */
	char *s;

	for (s = s1; (*s++ = *s2++) != '\0'; )
		;
	return (s1);
	}
#endif /* _INLINE || _STRCPY */

#if defined(_INLINE) || defined(_STRNCPY)
_OPT_IDEFN char *(strncpy)(char *_Restrict s1, const char *_Restrict s2,
	size_t n)
	{	/* copy char s2[max n] to s1[n] */
	char *s;

	for (s = s1; 0 < n && *s2 != '\0'; --n)
		*s++ = *s2++;	/* copy at most n chars from s2[] */
	for (; 0 < n; --n)
		*s++ = '\0';
	return (s1);
	}
#endif /* _INLINE || _STRNCPY  */

#if defined(_INLINE) || defined(_STRCAT)
_OPT_IDEFN char *(strcat)(char *_Restrict s1, const char *_Restrict s2)
	{	/* copy char s2[] to end of s1[] */
	char *s;

	for (s = s1; *s != '\0'; ++s)
		;			/* find end of s1[] */
	for (; (*s = *s2) != '\0'; ++s, ++s2)
		;			/* copy s2[] to end */
	return (s1);
	}
#endif /* _INLINE || _STRCAT */

#if defined(_INLINE) || defined(_STRNCAT)
_OPT_IDEFN char *(strncat)(char *_Restrict s1, const char *_Restrict s2, size_t n)
	{	/* copy char s2[max n] to end of s1[] */
	char *s;

	for (s = s1; *s != '\0'; ++s)
		;	/* find end of s1[] */
	for (; 0 < n && *s2 != '\0'; --n)
		*s++ = *s2++;	/* copy at most n chars from s2[] */
	*s = '\0';
	return (s1);
	}
#endif /* _INLINE || _STRNCAT */

#if defined(_INLINE) || defined(_STRCHR)
_OPT_IDEFN _Const_return char *(strchr)(const char *s, int c)
	{	/* find first occurrence of c in char s[] */
	const char ch = (char)c;

	for (; *s != ch; ++s)
		if (*s == '\0')
			return (0);
	return ((char *)s);
	}
#endif /* _INLINE || _STRCHR */

#if defined(_INLINE) || defined(_STRRCHR)
_OPT_IDEFN _Const_return char *(strrchr)(const char *s, int c)
	{	/* find last occurrence of c in char s[] */
	const char ch = (char)c;
	const char *sc;

	for (sc = 0; ; ++s)
		{	/* check another char */
		if (*s == ch)
			sc = s;
		if (*s == '\0')
			return ((char *)sc);
		}
	}
#endif /* _INLINE || _STRRCHR */

#if defined(_INLINE) || defined(_STRCMP)
_OPT_IDEFN int (strcmp)(const char *s1, const char *s2)
	{	/* compare unsigned char s1[], s2[] */
	for (; *s1 == *s2; ++s1, ++s2)
		if (*s1 == '\0')
			return (0);
	return (*(unsigned char *)s1 < *(unsigned char *)s2
		? -1 : +1);
	}
#endif /* _INLINE || _STRCMP */

#if defined(_INLINE) || defined(_STRNCMP)
_OPT_IDEFN int (strncmp)(const char *s1, const char *s2, size_t n)
	{	/* compare unsigned char s1[max n], s2[max n] */
	for (; 0 < n; ++s1, ++s2, --n)
		if (*s1 != *s2)
			return (*(unsigned char *)s1
				< *(unsigned char *)s2 ? -1 : +1);
		else if (*s1 == '\0')
			return (0);
	return (0);
	}
#endif /* _INLINE || _STRNCMP */

#if defined(_INLINE) || defined(_MEMCMP)
_OPT_IDEFN int (memcmp)(const void *s1, const void *s2, size_t n)
	{	/* compare unsigned char s1[n], s2[n] */
	const unsigned char *su1 = (const unsigned char *)s1;
	const unsigned char *su2 = (const unsigned char *)s2;

	for (; 0 < n; ++su1, ++su2, --n)
		if (*su1 != *su2)
			return (*su1 < *su2 ? -1 : +1);
	return (0);
	}
#endif /* _INLINE || _MEMCMP */


#if defined(_INLINE) || defined(_MEMCHR)
_OPT_IDEFN void *(memchr)(const void *s, int c, size_t n)
	{	/* find first occurrence of c in s[n] */
	const unsigned char uc = (unsigned char)c;
	const unsigned char *su = (const unsigned char *)s;

	for (; 0 < n; ++su, --n)
		if (*su == uc)
			return ((void *)su);
	return (0);
	}
#endif /* _INLINE || _MEMCHR */

#if ((defined(_INLINE) || defined(_MEMSET)) && !defined(__TMS320C6X__))
_OPT_IDEFN void *(memset)(void *s, int c, size_t n)
	{	/* store c throughout unsigned char s[n] */
	const unsigned char uc = (unsigned char)c;
	unsigned char *su = (unsigned char *)s;

	for (; 0 < n; ++su, --n)
		*su = uc;
	return (s);
	}
#endif /* _INLINE || _MEMSET */

#endif /* (_STRING_IMPLEMENTATION || !(_OPTIMIZE_FOR_SPACE && __TMS470__)) */
#endif /* (_INLINE || _STRING_IMPLEMENTATION) */
#endif /* defined(__TI_COMPILER_VERSION__) */
_C_STD_END
#endif /* _STRING */

 #if defined(_STD_USING)

  #ifdef _STD_USING_SIZE_T
using _CSTD size_t;
  #endif /* _STD_USING_SIZE_T */

using _CSTD memchr; using _CSTD memcmp;
using _CSTD memcpy; using _CSTD memmove; using _CSTD memset;
using _CSTD strcat; using _CSTD strchr; using _CSTD strcmp;
using _CSTD strcoll; using _CSTD strcpy; using _CSTD strcspn;
using _CSTD strerror; using _CSTD strlen; using _CSTD strncat;
using _CSTD strncmp; using _CSTD strncpy; using _CSTD strpbrk;
using _CSTD strrchr; using _CSTD strspn; using _CSTD strstr;
using _CSTD strtok; using _CSTD strxfrm;


 #endif /* defined(_STD_USING) */

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
